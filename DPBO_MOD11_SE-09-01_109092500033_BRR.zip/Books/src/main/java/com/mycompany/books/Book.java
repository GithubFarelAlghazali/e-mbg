/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.books;

/**
 *
 * @author User
 */
public class Book {
    private String title;
    private int price;
    
    public Book(String title, int price){
        this.title = title;
        this.price = price;
    }
    
    public String getTitle(){
        return this.title;
    }
    
    public int getPrice(){
        return this.price;
    }
    
    public String toString(){
        return "[Judul] " + this.title + " [Harga] " + this.price + " won";
    }
}
