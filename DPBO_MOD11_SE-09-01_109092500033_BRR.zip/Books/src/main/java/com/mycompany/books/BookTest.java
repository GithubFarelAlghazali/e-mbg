/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.books;
import java.util.Scanner;
/**
 *
 * @author User
 */
public class BookTest {
    public static void main(String[] args){
        BookBiz bookSystem = new BookBiz();
        Scanner sc = new Scanner(System.in);
        
        Magazine m1 = new Magazine("Cooking Light", 15000, "living, cooking", "America Cooking");
        Magazine m2 = new Magazine("Auto Bild", 16000, "science, car", "Germany Car");

        Novel n1 = new Novel("The Confession", 10500, "Grisham, John");
        Novel n2 = new Novel("Les Miserables", 17500, "Hugo, Victor");
        Novel n3 = new Novel("Breakthrough", 47200, "Ifill, Gwen");
        Novel n4 = new Novel("The Racketeer", 38000, "Grisham, John");

        Book[] daftarBuku = {m1, m2, n1, n2, n3, n4};

        int menu = -1;
        while(menu != 9){
            System.out.println("=====<< Program Informasi Buku >>=====");
            System.out.println("1. Mencari seluruh informasi buku");
            System.out.println("2. Mencari nama penulis novel");
            System.out.println("3. Mencari harga novel (harga terendah ke harga tertinggi)");
            System.out.println("9. Keluar");
            bookSystem.printTail();
            System.out.print("Pilih menu : ");
            menu = sc.nextInt();
            
            switch(menu){
                case 1:
                    bookSystem.printHeader();
                    bookSystem.printAllBooks();
                    bookSystem.printTail();
                    break;
                case 2:
                    System.out.print("Masukkan nama penulis yang ingin dicari : ");
                    String author = sc.nextLine();
                    bookSystem.searchNovelByAuthor(author);
                    break;
                case 3:
                    int minPrice, maxPrice;
                    System.out.print("Masukkan harga minimum untuk novel yang ingin dicari : ");
                    minPrice = sc.nextInt();
                    System.out.print("Masukkan harga maksimum untuk novel yang ingin dicari : ");
                    maxPrice = sc.nextInt();
                    bookSystem.searchNovelByPrice(minPrice, maxPrice);
                    break;
                case 9:
                    System.out.println("Berhenti. Bye");
            }   
    }
        
}
}