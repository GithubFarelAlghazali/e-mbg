/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.books;

/**
 *
 * @author User
 */
public class Magazine extends Book{
    private String category;
    private String description;
    
    public Magazine(String title, int price, String category, String desc){
        super(title, price);
        this.category = category;
        this.description = desc;
    }
    
    public String getCategory(){
        return this.category;
    }
    
    public String getDescription(){
        return this.description;
    }
    
    @Override
    public String toString(){
        return super.toString() + " [Kategori] " + this.category + " [Keterangan] " + this.description;
    }
}
