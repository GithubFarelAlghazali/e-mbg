/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.books;

/**
 *
 * @author User
 */
public interface IBookBiz {
    public void printAllBooks();
    public void searchNovelByAuthor(String author);
    public void searchNovelByPrice(int minPrice, int maxPrice);
    public void printHeader();
    public void printTail();
}
