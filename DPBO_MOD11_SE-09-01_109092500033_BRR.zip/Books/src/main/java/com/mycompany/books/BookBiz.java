/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.books;

/**
 *
 * @author User
 */
public class BookBiz implements IBookBiz {
    private Book[] books;
    
    public BookBiz(){
    Magazine m1 = new Magazine("Cooking Light", 15000, "living, cooking", "America Cooking");
        Magazine m2 = new Magazine("Auto Bild", 16000, "science, car", "Germany Car");

        Novel n1 = new Novel("The Confession", 10500, "Grisham, John");
        Novel n2 = new Novel("Les Miserables", 17500, "Hugo, Victor");
        Novel n3 = new Novel("Breakthrough", 47200, "Ifill, Gwen");
        Novel n4 = new Novel("The Racketeer", 38000, "Grisham, John");

        // Array 'books' langsung diisi di sini
        this.books = new Book[]{m1, m2, n1, n2, n3, n4};}
    
    public BookBiz(Book[] books) {
        this.books = books;
    }
    
    public void printAllBooks(){
        if (books == null) {
            System.out.println("Data buku belum diinisialisasi!");
            return;
        }
        for(Book book : books){
            System.out.println(book.toString());
        }
    }
    
    public void searchNovelByAuthor(String author){
        for(Book book : books){
            if(book instanceof Novel){
                if(((Novel) book).getAuthor().contains(author)){
                    System.out.println(book.toString());
                }
        }
        }
    }
    
    public void searchNovelByPrice(int minPrice, int maxPrice){
        for(Book book : books){
            if(book.getPrice() <= maxPrice && book.getPrice() >= minPrice){
                System.out.println(book.toString());
            }
        }
    }
    
    public void printHeader(){
        System.out.println("------------ Informasi Buku ------------");
    }
    public void printTail(){
        System.out.println("------------------------------------------");
    }
}
